/**
 * SmileBrush Google Sheets receiver.
 * Create tabs named Orders and Order_Items, then paste this code in Apps Script.
 * Deploy as Web app: Execute as Me; access: Anyone.
 */
const ORDERS_SHEET = "Orders";
const ITEMS_SHEET = "Order_Items";

function doPost(e) {
  try {
    const data = JSON.parse(e.postData.contents);
    const ss = SpreadsheetApp.getActiveSpreadsheet();
    const orders = ss.getSheetByName(ORDERS_SHEET);
    const items = ss.getSheetByName(ITEMS_SHEET);
    if (!orders || !items) throw new Error("ไม่พบชีต Orders หรือ Order_Items");

    orders.appendRow([
      data.orderId, new Date(data.createdAt), data.customer.name,
      data.customer.phone, data.customer.email || "",
      data.customer.address, data.customer.province,
      data.customer.postcode, data.customer.note || "",
      data.total, data.status
    ]);

    (data.items || []).forEach(item => items.appendRow([
      data.orderId, item.sku, item.name, item.quantity, item.unitPrice, item.lineTotal
    ]));

    return json({ ok: true, orderId: data.orderId });
  } catch (err) {
    return json({ ok: false, message: err.message });
  }
}

function doGet() {
  return json({ ok: true, service: "SmileBrush order endpoint" });
}

function json(value) {
  return ContentService.createTextOutput(JSON.stringify(value))
    .setMimeType(ContentService.MimeType.JSON);
}
