import { useMemo, useState } from "react";
import { ShoppingBag, Menu, X, Plus, Minus, CheckCircle2, PackageCheck, Leaf, ShieldCheck, Truck } from "lucide-react";
import { submitOrder } from "./lib/api";

const products = [
  { sku: "TB-001", name: "Soft Clean", subtitle: "ขนนุ่มพิเศษ อ่อนโยนต่อเหงือก", price: 89, oldPrice: 109, color: "mint", image: "/images/TB-001.svg", tag: "ขายดี" },
  { sku: "TB-002", name: "Charcoal Clean", subtitle: "ผสมชาร์โคล ทำความสะอาดอย่างมั่นใจ", price: 129, oldPrice: 149, color: "sand", image: "/images/TB-002.svg", tag: "ใหม่" }
];

const money = n => new Intl.NumberFormat("th-TH", { style: "currency", currency: "THB", maximumFractionDigits: 0 }).format(n);

export default function App() {
  const [cart, setCart] = useState({});
  const [drawer, setDrawer] = useState(false);
  const [checkout, setCheckout] = useState(false);
  const [notice, setNotice] = useState("");
  const [busy, setBusy] = useState(false);
  const [form, setForm] = useState({ name: "", phone: "", email: "", address: "", province: "", postcode: "", note: "" });
  const count = Object.values(cart).reduce((a, b) => a + b, 0);
  const total = useMemo(() => products.reduce((sum, p) => sum + p.price * (cart[p.sku] || 0), 0), [cart]);

  const changeQty = (sku, delta) => setCart(prev => {
    const next = { ...prev, [sku]: Math.max(0, (prev[sku] || 0) + delta) };
    if (!next[sku]) delete next[sku];
    return next;
  });

  const placeOrder = async e => {
    e.preventDefault();
    if (!count) return;
    setBusy(true);
    const order = {
      orderId: `SB${Date.now().toString().slice(-8)}`,
      createdAt: new Date().toISOString(),
      customer: form,
      items: products.filter(p => cart[p.sku]).map(p => ({ sku: p.sku, name: p.name, quantity: cart[p.sku], unitPrice: p.price, lineTotal: p.price * cart[p.sku] })),
      total,
      status: "รอหยิบสินค้า"
    };
    try {
      const result = await submitOrder(order);
      setNotice(result.demo
        ? `รับคำสั่งซื้อ ${order.orderId} แล้ว (โหมดทดลอง: ยังไม่ได้ส่งเข้า Google Sheets)`
        : `รับคำสั่งซื้อ ${order.orderId} เรียบร้อยแล้ว`);
      setCart({});
      setCheckout(false);
      setDrawer(false);
      setForm({ name: "", phone: "", email: "", address: "", province: "", postcode: "", note: "" });
    } catch (err) {
      setNotice(err.message || "เกิดข้อผิดพลาด กรุณาลองอีกครั้ง");
    } finally { setBusy(false); }
  };

  return <div>
    <div className="topline">ส่งฟรีเมื่อซื้อครบ 399 บาท · ดูแลรอยยิ้มของคุณทุกวัน</div>
    <header className="header wrap">
      <a className="brand" href="#"><span className="brand-mark">S</span><span>smile<span className="brand-light">brush</span><small>EVERYDAY CARE</small></span></a>
      <nav><a href="#products">สินค้า</a><a href="#about">ทำไมต้อง SmileBrush</a><a href="#contact">ติดต่อเรา</a></nav>
      <button className="cart-button" onClick={() => setDrawer(true)}><ShoppingBag size={18}/> ตะกร้า <b>{count}</b></button>
    </header>

    <main>
      <section className="hero wrap">
        <div className="hero-copy">
          <span className="eyebrow"><span/> SMALL HABITS, BRIGHT SMILES</span>
          <h1>เริ่มต้นรอยยิ้มที่ดี<br/><em>ได้ทุกวัน</em></h1>
          <p>แปรงสีฟันที่ใส่ใจทุกรายละเอียด เพื่อการดูแลช่องปากที่อ่อนโยนและมั่นใจในทุกเช้าและก่อนนอน</p>
          <a className="primary" href="#products">เลือกแปรงสีฟัน <span>↗</span></a>
          <div className="hero-note"><ShieldCheck size={17}/> คัดสรรวัสดุเพื่อการดูแลช่องปากในทุกวัน</div>
        </div>
        <div className="hero-art">
          <div className="sun-disc"></div><div className="hero-label">YOUR DAILY<br/>SMILE ROUTINE</div>
          <img src="/images/TB-001.svg" alt="แปรงสีฟัน SmileBrush Soft Clean" />
          <div className="float-card"><span>✦</span><div><b>Gentle care</b><small>อ่อนโยนทุกครั้งที่แปรง</small></div></div>
        </div>
      </section>

      <section className="benefits wrap" id="about">
        <div><span><Leaf/></span><b>อ่อนโยนต่อเหงือก</b><small>สัมผัสนุ่มสบายในทุกวัน</small></div>
        <div><span><ShieldCheck/></span><b>ใส่ใจคุณภาพ</b><small>เลือกใช้วัสดุอย่างพิถีพิถัน</small></div>
        <div><span><Truck/></span><b>จัดส่งถึงบ้าน</b><small>แพ็คสินค้าอย่างใส่ใจ</small></div>
      </section>

      <section className="products-section" id="products">
        <div className="wrap">
          <div className="section-heading"><div><span className="eyebrow">OUR COLLECTION</span><h2>เลือกแบบที่ใช่สำหรับคุณ</h2></div><p>สองตัวเลือกสำหรับกิจวัตรดูแลช่องปาก<br/>ที่คุณอยากทำทุกวัน</p></div>
          <div className="product-grid">
            {products.map(p => <article className={`product-card ${p.color}`} key={p.sku}>
              <div className="product-image"><span className="tag">{p.tag}</span><img src={p.image} alt={p.name}/></div>
              <div className="product-info"><span className="sku">{p.sku}</span><h3>{p.name}</h3><p>{p.subtitle}</p><div className="buy-row"><div><b>{money(p.price)}</b><del>{money(p.oldPrice)}</del></div><button onClick={() => { changeQty(p.sku, 1); setNotice(`เพิ่ม ${p.name} ลงตะกร้าแล้ว`); }} aria-label={`เพิ่ม ${p.name} ลงตะกร้า`}><Plus size={19}/></button></div></div>
            </article>)}
          </div>
        </div>
      </section>

      <section className="closing wrap" id="contact"><div><span className="eyebrow">A LITTLE CARE GOES A LONG WAY</span><h2>รอยยิ้มที่ดี เริ่มจากสิ่งเล็ก ๆ</h2><p>ขอบคุณที่ให้ SmileBrush เป็นส่วนหนึ่งของทุกวัน</p></div><a href="#products">เลือกซื้อสินค้า ↗</a></section>
    </main>
    <footer><div className="wrap footer-inner"><a className="brand" href="#"><span className="brand-mark">S</span><span>smile<span className="brand-light">brush</span><small>EVERYDAY CARE</small></span></a><small>© 2026 SmileBrush · Demo online store</small></div></footer>

    {notice && <div className="toast" role="status"><CheckCircle2 size={18}/>{notice}<button onClick={() => setNotice("")}><X size={16}/></button></div>}

    {drawer && <div className="overlay" onMouseDown={e => { if (e.target === e.currentTarget) setDrawer(false); }}>
      <aside className="drawer"><div className="drawer-head"><h2>{checkout ? "ข้อมูลจัดส่ง" : "ตะกร้าสินค้า"}</h2><button className="icon-button" onClick={() => {setDrawer(false);setCheckout(false);}}><X/></button></div>
        {!checkout ? <>
          {count === 0 ? <div className="empty"><ShoppingBag size={34}/><p>ยังไม่มีสินค้าในตะกร้า</p><button className="primary" onClick={() => setDrawer(false)}>เลือกสินค้า</button></div> :
            <><div className="cart-lines">{products.filter(p => cart[p.sku]).map(p => <div className="cart-line" key={p.sku}><img src={p.image}/><div className="line-detail"><b>{p.name}</b><small>{money(p.price)}</small><div className="qty"><button onClick={() => changeQty(p.sku,-1)}><Minus size={13}/></button><span>{cart[p.sku]}</span><button onClick={() => changeQty(p.sku,1)}><Plus size={13}/></button></div></div><b>{money(p.price*cart[p.sku])}</b></div>)}</div><div className="drawer-total"><span>ยอดรวมสินค้า</span><b>{money(total)}</b></div><p className="shipping-hint">{total >= 399 ? "คุณได้รับสิทธิ์ส่งฟรีแล้ว" : `ซื้อเพิ่มอีก ${money(399-total)} เพื่อรับส่งฟรี`}</p><button className="primary full" onClick={() => setCheckout(true)}>ดำเนินการสั่งซื้อ</button></>}
        </> : <form className="checkout-form" onSubmit={placeOrder}>
          <p className="form-intro">กรอกข้อมูลให้ครบถ้วนเพื่อจัดส่งสินค้า</p>
          <label>ชื่อ-นามสกุล<input required value={form.name} onChange={e=>setForm({...form,name:e.target.value})} placeholder="ชื่อผู้รับพัสดุ"/></label>
          <div className="form-two"><label>เบอร์โทรศัพท์<input required inputMode="tel" value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})} placeholder="08X-XXX-XXXX"/></label><label>อีเมล (ถ้ามี)<input type="email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})} placeholder="you@email.com"/></label></div>
          <label>ที่อยู่จัดส่ง<textarea required rows="3" value={form.address} onChange={e=>setForm({...form,address:e.target.value})} placeholder="บ้านเลขที่ ถนน แขวง/ตำบล เขต/อำเภอ"/></label>
          <div className="form-two"><label>จังหวัด<input required value={form.province} onChange={e=>setForm({...form,province:e.target.value})}/></label><label>รหัสไปรษณีย์<input required inputMode="numeric" value={form.postcode} onChange={e=>setForm({...form,postcode:e.target.value})}/></label></div>
          <label>หมายเหตุ<textarea rows="2" value={form.note} onChange={e=>setForm({...form,note:e.target.value})} placeholder="รายละเอียดเพิ่มเติม (ถ้ามี)"/></label>
          <div className="drawer-total"><span>ยอดชำระสินค้า</span><b>{money(total)}</b></div>
          <button className="primary full" disabled={busy}>{busy ? "กำลังบันทึก..." : "ยืนยันคำสั่งซื้อ"}</button>
          <button type="button" className="back-link" onClick={() => setCheckout(false)}>← กลับไปแก้ไขตะกร้า</button>
        </form>}
      </aside>
    </div>}
  </div>;
}
